package com.earner.pro.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.HashMap;
import java.util.Map;
import okhttp3.*;

public class SurveyBotService extends Service {
    
    private OkHttpClient client;
    private String[] surveySites = {
        "https://www.surveyjunkie.com",
        "https://www.swagbucks.com/surveys",
        "https://www.prizerebel.com/surveys",
        "https://www.toluna.com",
        "https://www.yougov.com"
    };
    
    @Override
    public void onCreate() {
        super.onCreate();
        client = new OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startSurveyBot();
        return START_STICKY;
    }
    
    private void startSurveyBot() {
        new Thread(() -> {
            while (true) {
                try {
                    for (String site : surveySites) {
                        completeSurvey(site);
                        Thread.sleep(60000); // Wait 1 minute
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
    
    private void completeSurvey(String site) {
        // Random user data
        Map<String, String> userData = new HashMap<>();
        userData.put("name", generateRandomName());
        userData.put("email", generateRandomEmail());
        userData.put("age", String.valueOf(25 + (int)(Math.random() * 40)));
        userData.put("gender", Math.random() > 0.5 ? "male" : "female");
        userData.put("income", String.valueOf(30000 + (int)(Math.random() * 100000)));
        userData.put("education", getRandomEducation());
        userData.put("employment", getRandomEmployment());
        
        // Submit survey form
        FormBody.Builder formBuilder = new FormBody.Builder();
        for (Map.Entry<String, String> entry : userData.entrySet()) {
            formBuilder.add(entry.getKey(), entry.getValue());
        }
        
        Request request = new Request.Builder()
            .url(site + "/api/submit")
            .post(formBuilder.build())
            .addHeader("User-Agent", getRandomUserAgent())
            .addHeader("Referer", site)
            .build();
        
        try {
            Response response = client.newCall(request).execute();
            response.close();
        } catch (Exception e) {}
    }
    
    private String generateRandomName() {
        String[] firstNames = {"John", "Jane", "Mike", "Sarah", "David", "Lisa", "James", "Emma"};
        String[] lastNames = {"Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller"};
        return firstNames[(int)(Math.random() * firstNames.length)] + " " +
               lastNames[(int)(Math.random() * lastNames.length)];
    }
    
    private String generateRandomEmail() {
        return generateRandomName().toLowerCase().replace(" ", ".") + 
               (int)(Math.random() * 1000) + "@gmail.com";
    }
    
    private String getRandomEducation() {
        String[] edu = {"High School", "Bachelor's", "Master's", "PhD", "Associate's"};
        return edu[(int)(Math.random() * edu.length)];
    }
    
    private String getRandomEmployment() {
        String[] emp = {"Full-time", "Part-time", "Self-employed", "Student", "Retired"};
        return emp[(int)(Math.random() * emp.length)];
    }
    
    private String getRandomUserAgent() {
        String[] agents = {
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_0 like Mac OS X) AppleWebKit/605.1.15"
        };
        return agents[(int)(Math.random() * agents.length)];
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}