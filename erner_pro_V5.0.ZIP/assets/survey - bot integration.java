// SurveyBotService.java - Background Service
package com.earner.pro.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import com.earner.pro.MainActivity;
import com.earner.pro.bot.SurveyBot;

public class SurveyBotService extends Service {
    
    private static final String CHANNEL_ID = "survey_bot_channel";
    private SurveyBot surveyBot;
    
    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(2, createNotification());
        
        // Initialize survey bot
        surveyBot = new SurveyBot(this);
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Start survey bot
        surveyBot.start();
        
        // Update notification every minute with stats
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(60000);
                    updateNotification();
                } catch (InterruptedException e) {
                    break;
                }
            }
        }).start();
        
        return START_STICKY;
    }
    
    @Override
    public void onDestroy() {
        if (surveyBot != null) {
            surveyBot.stop();
        }
        super.onDestroy();
    }
    
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Survey Bot",
                NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
    
    private Notification createNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Earner Pro")
            .setContentText("Taking surveys in background...")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .build();
    }
    
    private void updateNotification() {
        if (surveyBot != null) {
            SurveyBot.SurveyStats stats = surveyBot.getStats();
            Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Earner Pro")
                .setContentText("Completed: " + stats.totalCompleted + " surveys | Earned: $" + 
                    String.format("%.2f", stats.totalEarned))
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .build();
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.notify(2, notification);
        }
    }
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}